import http from "http";
import WebSocket from "ws";
import express from "express";

const app = express();

app.set("view engine","pug");
app.set("views", __dirname + "/views");
app.use("/public", express.static(__dirname + "/public"));
app.get("/", (req,res) => res.render("home"));

const handleListen = () => console.log('Listening on http://localhost:3000');

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });


//on method는 backend에 연결된 사람의 정보를 제공. 그게 여기 socket에서옴
//이렇게 쓰고, web socket을 이용해서 새로운 connection을 기다림 
wss.on("connection", (socket) => {
    console.log("connected to browser ✅");
    socket.on("close", () => console.log("disconnected from the Browser ❌"));

    // socket.on("message", message => {
    //     console.log(message);
    // });

    // socket.on("message", message => {
    // console.log(message.toString('utf8'));
    // });
    socket.on("message", (message) => {
        console.log(message.toString());
        });        
    socket.send("hello!");
});

    
server.listen(3000, handleListen);